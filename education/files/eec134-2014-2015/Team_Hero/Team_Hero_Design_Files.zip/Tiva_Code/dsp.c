/*
 * dsp.c
 *
 *  Created on: Apr 18, 2015
 *      Author: pahuynh
 *
 *  Notes on dsp.c:
 *  	Uses extern to grab the gobal variables related to sampling frequency and
 *  	data from sampling.c
 *
 */

// Needed on top of each file
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

#include "inc/hw_adc.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"

#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/udma.h"

#include "dsp.h"
#include "sampling.h"
#include "arm_math.h"


//*****************************************************************************
//
// Global variables
//
//*****************************************************************************

// Stores the sampled data
// From sampling.c
extern unsigned short g_ulADCValues[NUM_SAMPLES];

// Flag from the uDMA engine signaling that data is ready to be processed
// Also from sampling.c
extern volatile unsigned char g_ucDataReady;

// Sampling Frequency
// Defined in sampling.c
extern const unsigned int g_uiSamplingFreq;

// The range in Hertz of each frequency bin
float g_HzPerBin;

// These hold the updated processed data.
unsigned int reFreq = 0;
unsigned int speed = 0;

//*****************************************************************************
//
// Private predefines and variables used for the FFT portion of the DSP loop
//
//*****************************************************************************

// Flag used to determine whether to calculate forward (0) or inverse(1) fft
#define INVERT_FFT				0

// Flag used to determine if fft result will be output in standard bit order(1)
// or reversed bit order (0)
#define BIT_ORDER_FFT			1

// The array used to store the results of the fast fourier transform.  Each
// element in this array represents the power found in a frequency bin of width
// Fs / FFT_length
static float32_t g_fFFTResult[NUM_SAMPLES * 2];

// FFT and CMSIS config structures
arm_rfft_instance_f32 fftStructure;
arm_cfft_radix4_instance_f32 cfftStructure;

// Hamming window, used to prepare samples for fft and correct for the fact
// we're using an algorithm meant for a continuous, infinite signal on a
// signal that is finite and not always continuous.
extern float ti_hamming_window_vector[NUM_SAMPLES];


//*****************************************************************************
//
// InitDSP():
//
//	Calculats the Hz per bin infrequency domain.
//  Also initializes the fft structure.
//
//*****************************************************************************
void InitDSP(void){

	// Determine the
	g_HzPerBin = (float)g_uiSamplingFreq / (float)NUM_SAMPLES;

	// Call the CMSIS real fft init function
	arm_rfft_init_f32(&fftStructure, &cfftStructure, NUM_SAMPLES, INVERT_FFT, BIT_ORDER_FFT);

}// InitDSP()


//*****************************************************************************
//
// ProcessData():
//
// EuphonistiHack Notes:
// Run the DSP calculations on the input vector.
//
// Step 1: multiply vector by hamming window
// Step 2: get fast fourier transform of samples
// Step 3: get complex power of each element in fft output
// Step 4: figure out power in each LED range of bins, compare to previously
//		   observed maximum power, and set global LED array for that LED column
//		   accordingly
// Step 5: ???
// Step 6: Profit
//
// Patrick's Notes:
// So far do not need upper and lower bound.
//
//
//*****************************************************************************
void ProcessData(void){

	// For indexing
	uint32_t i;

	// For finding bin with highest power
	float32_t maxValue;

	// Ugly, ugly, ugly part where we have to move the ul samples into a float
	// array because the fixed point fft functions in CMSIS seem to be not
	// working.  While we're at it, we might as well center the samples around
	// 0, as the CMSIS algorithm seems to like that.
	for(i=0;i<NUM_SAMPLES;i++)
	{
		g_fFFTResult[i] = ((float)g_ulADCValues[i] - (float)0x800);// / (float)640; 1.5 V
		//g_fFFTResult[i] = ((float)g_ulADCValues[i] - (float)0x600);// / 1.1 V
	}// for

	// Multiply samples by hamming window
	arm_mult_f32(g_fFFTResult, ti_hamming_window_vector, g_fFFTResult, NUM_SAMPLES);

	// Calculate FFT on samples
	arm_rfft_f32(&fftStructure, g_fFFTResult, g_fFFTResult);

	// Calculate complex power of FFT results
	arm_cmplx_mag_f32(g_fFFTResult, g_fFFTResult, NUM_SAMPLES * 2);

	// find the maximum bin
	arm_max_f32(g_fFFTResult, NUM_SAMPLES, &maxValue, &i);

	// Update received frequency
	// Might need to multiple by the constant
	//reFreq = (int)(g_HzPerBin*i);
	reFreq = (int)(1.205*g_HzPerBin*i);

	// Update speed
	// Cast integer variables as floats to have more accurate division
	// 24 GHz tranmitted
	speed = (((float)reFreq/(float)g_uiSamplingFreq) - 1.0)*2400000000.0;

	// Clear the data ready bit and set up the next DMA transfer
	g_ucDataReady = 0;

	uDMAChannelTransferSet(UDMA_CHANNEL_ADC3 | UDMA_PRI_SELECT,
						   UDMA_MODE_BASIC,
						   (void *)(ADC0_BASE + ADC_O_SSFIFO3 + (0x20 * UDMA_ARB_1)),
						   g_ulADCValues, UDMA_XFER_MAX);

	// Enable the timer and start the sampling timer
	uDMAChannelEnable(UDMA_CHANNEL_ADC3);
	TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/(g_uiSamplingFreq - 1));
	TimerEnable(TIMER0_BASE, TIMER_A);


}// ProcessData()





