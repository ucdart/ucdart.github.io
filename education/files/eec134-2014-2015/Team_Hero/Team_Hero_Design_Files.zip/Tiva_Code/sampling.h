/*
 * sampling.h
 *
 *  Created on: May 2, 2015
 *      Author: pahuynh
 *
 *  Notes on sampling.h:
 *  	Defines some stuff that's common to both dsp and sampling.
 *
 */

#ifndef SAMPLING_H_
#define SAMPLING_H_

//*****************************************************************************
//
// Preprocessor macros
// The reason these variables are put here instead of elsewhere is
// because dsp.c and sampling.c needs these variables. It's more convenient
// to put them here instead of a c file.
//
//*****************************************************************************

// The ADC sequencer to be used to sample the audio signal
// So currently it uses ADC0 Sequencer 3
#define ADC_SEQUENCER			3

// The maximum number of transfers one UDMA transaction can complete
// I guess it's becasue the uDMA control table has a 1024 byte boundary
#define UDMA_XFER_MAX			1024


// Functions
void ADC3IntHandler(void);
void InitADC3Transfer(void);
void Timer0AIntHandler(void);
void InitSamplingTimer(void);
void uDMAErrorHandler(void);

#endif /* SAMPLING_H_ */
