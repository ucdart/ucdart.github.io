/*
 * dac.c
 *
 *  Created on: May 2, 2015
 *      Author: pahuynh
 *
 *  Notes on dac.c:
 *  	Seems to have problems with the touchscreen.
 *  	Having CS as PD1 seems to have problems.
 *
 * Uses SSI3
 * SSI3_CLK Pin = PD0
 * SSI3_Din Pin = PD3
 * DAC1_CS Pin  = PD1 coarse
 * DAC2_CS Pin 	= PD2 fine
 *
 *
 */

// Needed on top of each file
// Defines data types like unint32_t
#include <stdint.h>
#include <stdbool.h>

// Might actually be Model number RB2,
// not defined in Tivaware library.
// So that ROM calls work
#define TARGET_IS_BLIZZARD_RB1
#include "driverlib/rom.h"

// Other includes, mostly for pins
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

// For timer and interrupts
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

// For SSI
#include "driverlib/ssi.h"

// Custom includes
#include "dac.h"

//*****************************************************************************
//
// Global variables:
//
// These variables help keep track of where the program should be on the
// triangle wave
//
//*****************************************************************************

// Determines whether you are on the falling or rising edge of the triangle wave
// true is the rising edge, false is the falling edge
volatile bool edge = true;

// The outputValue is a number from 0 to peak that determines
// the voltage level of the DAC. It starts at 0 because it
// starts at the bottom of the wave.
volatile unsigned int outputValue = 0;

// data is the 8 bit word that the Tiva sends into the DAC
// data is either the low byte of outputValue or the high
// byte of output value with control bits added in
volatile char data = 0;

// Sets the maximum value of outputValue
unsigned int peak = PEAK_12_BIT;

// Controls how much outputValue increments by
const unsigned int step = 40;


//
// Write data from Tiva to DAC through SSI
//
void writeData(uint8_t c)
{
	//Does the whole SPI process EXCEPT Slave Select low
	SSIDataPut(SSI3_BASE, c);

	// Checks if the DAC is still processing the data
	// should exit once all transmitted bits are processed
	while(SSIBusy(SSI3_BASE))
	{
	}// while
}// writeData()


//
// Take the high byte of a 16 bit word
//
int highByte(int x)
{
	return (0xff00 & x)>>8;
}// highbyte()


//
// Take the low byte of a 16 bit word
//
int lowByte(int x)
{
	return (0x00ff & x);
}// lowbyte()


//
// Writing to a single 12 bit DAC
//
void write12bit(void)
{
	//ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, 0);	//SS low
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, 0);	//SS low

	// 12 bit DAC
	data = highByte(outputValue);    	// Take the upper byte
	data = 0x0F & data;
	data = 0x30 | data;
	writeData(data); // Send the upper byte

	data = lowByte(outputValue);     // Shift in the 8 lower bits
	writeData(data);	// Send the lower byte

	//ROM_GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);	//SS High
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);	//SS High





	// Write infineon over and over again
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, 0);	//SS low
	writeData(0x00); // Send the upper byte
	writeData(0x18);	// Send the lower byte
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, GPIO_PIN_6);	//SS High

}// write12bit()

//
// Writing to a single 16 bit DAC
//
void write16bit(void)
{
	// Write to one DAC: Coarse
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1 , 0);	//SS Low
	writeData(0x00); // Send the control byte
	data = highByte(outputValue);
	writeData(data);	// Send the upper byte
	data = lowByte(outputValue);
	writeData(data); // Send the lower byte
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);	//SS High

}// write16bit()

//
// Setup SSI
//
void InitSSI()
{
	// for CLK and data
	//ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI3);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI3);

	// Delay for peripheral to initialize
	SysCtlDelay(3);

	// enable slave select port
	//ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);

	// Delay for peripheral to initialize
	SysCtlDelay(3);

	// Enable NEW SS pin as GPIO
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_6 );
	//GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1 );

	// Set to high for now
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_6, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_6);	//SS High
	//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);	//SS High

	// Configure pin to transmit (MOSI)
	GPIOPinConfigure(GPIO_PD3_SSI3TX);

	// Configure pins to be used as SSI Clock and Data
	GPIOPinTypeSSI(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_3);

	// Initializes SSI
	// Parameters are: 	base address of the SSI
	//					the clock supplied to the SSI
	//					data frame format
	//					configure SSI as master as opposed to slave
	//					the bit rate (should be lower than system clock by at least factor of 4)
	//					word size
	SSIConfigSetExpClk(SSI3_BASE, SysCtlClockGet(), SSI_FRF_MOTO_MODE_0,  SSI_MODE_MASTER, SysCtlClockGet()/4, 8);

	// Configure pin as a clock
	GPIOPinConfigure(GPIO_PD0_SSI3CLK);

	// Enable SSI
	//ROM_SSIEnable(SSI3_BASE);
	SSIEnable(SSI3_BASE);



	// Write infineon
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, 0);	//SS low
	writeData(0x00); // Send the upper byte
	writeData(0x18);	// Send the lower byte
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_6, GPIO_PIN_6);	//SS High

	// Set one DAC to constant: fine
	//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_2 , 0);	//SS Low
	//writeData(0x00); // Send the control byte

	//writeData(0x00);	// Send the upper byte
	//writeData(0x00); // Send the lower byte
	//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_2, GPIO_PIN_2);	//SS High

	// Set other DAC to constant
	//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1 , 0);	//SS Low
	//writeData(0x00); // Send the control byte
	//writeData(0x11);	// Send the upper byte
	//writeData(0x11); // Send the lower byte
	//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);	//SS High

}// InitSSI()



//*****************************************************************************
//
//  Timer2AIntHandler():
//
//
//
//*****************************************************************************
void
Timer2AIntHandler(void)
{
    // Clear the timer interrupt.
    TimerIntClear(TIMER2_BASE, TIMER_TIMA_TIMEOUT);

	//
	// Determine where you are on the triangluar wave
	// edge determines if you are on the rising or
	// falling edge of the wave.
	// peak is the maximum value.
	// output value is the 12 data bits that are being
	// sent to the DAC
	//

	// If on the rising edge of the wave
	if (edge) {

		// Increment the data bits
		outputValue += step;

		// Check if at the peak or above the wave
		if (outputValue >= peak) {

			// Go from rising edge to falling edge
			edge = !edge;

		}// if
	}// if

	// Else on the falling edge of the wave
	else {

		// Decrement the data bits
		outputValue -= step;

		// Check if at zero or below (below zero is bad)
		if (outputValue <= 0) {

			// Go from rising edge to falling edge
			edge = !edge;

		}// if
	}// else

	// Write data
	write12bit();

}// Timer2AIntHandler()



//*****************************************************************************
//
// InitDACTimer():
//
// EuphonistiHack Notes:
// Initialize the 1/second debug timer.
//
// Patrick's Notes:
// Doesn't seem important. Want to change this to the DAC timer.
//
// Todo: Change this to the DAC timer.
//
//*****************************************************************************
void
InitDACTimer(void)
{
	// Determine the frequency at which the interrupt is called
	// Also determines the frequency of the triangle wave
	// So far: 	10 kHz dacFreq is about 5 Hz trangle wave
	//			100 kHz dacFreq is about 59 Hz triangle wave

	const uint32_t timerFreq = 10000;
	//const uint32_t timerFreq = 1000;
	uint32_t ui32Period;		// Determines the cycles

	// Enable the configuration of Timer2
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);

    // It loads
    TimerConfigure(TIMER2_BASE, TIMER_CFG_PERIODIC);

	// Divide system clock freq by constant to get # of clock cycles
	// for the timer to count down
	ui32Period = SysCtlClockGet() / timerFreq;

    // Set it to the clock frequency
    TimerLoadSet(TIMER2_BASE, TIMER_A, ui32Period -1);

    // Enable the interrupt associated with this timer
    IntEnable(INT_TIMER2A);

    // Set the interrupt to be called when the timer
    // runs out
    TimerIntEnable(TIMER2_BASE, TIMER_TIMA_TIMEOUT);

    // Enable the timer
    TimerEnable(TIMER2_BASE, TIMER_A);

}// InitDACTimer()
