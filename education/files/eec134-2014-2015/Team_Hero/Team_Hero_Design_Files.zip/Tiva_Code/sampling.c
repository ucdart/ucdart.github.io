/*
 * sampling.c
 *
 *  Created on: May 2, 2015
 *      Author: pahuynh
 *
 *  Notes on sampling.c:
 *  	Contains the timer0 and interrupts for the adc here.
 *  	Init the uDMA control table here.
 *
 */

// Needed on top of each file
// Defines data types like unint32_t
#include <stdint.h>
#include <stdbool.h>

// Might actually be Model number RB2,
// not defined in Tivaware library.
// So that ROM calls work
#define TARGET_IS_BLIZZARD_RB1
#include "driverlib/rom.h"

// Other includes, mostly for pins
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

// For timer and interrupts
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

// For the uDMA
#include "driverlib/udma.h"

// For adc
#include "inc/hw_adc.h"
#include "driverlib/adc.h"

// Custom includes
#include "sampling.h"
#include "dsp.h" // Needed for NUM_SAMPLES


//*****************************************************************************
//
// Preprocessor statements and global variables for audio capture and signal
// processing
//
//*****************************************************************************

// The control table used by the uDMA controller.  This table must be aligned
// to a 1024 byte boundary.
#if defined(ewarm)
#pragma data_alignment=1024
unsigned char ucControlTable[1024];
#elif defined(ccs)
#pragma DATA_ALIGN(ucControlTable, 1024)
unsigned char ucControlTable[1024];
#else
unsigned char ucControlTable[1024] __attribute__ ((aligned(1024)));
#endif

// Stores the sampled data
unsigned short g_ulADCValues[NUM_SAMPLES];

// Flag from the uDMA engine signaling that data is ready to be processed
volatile unsigned char g_ucDataReady;

// Sampling Frequency
// If you want it to change, edit the number and then recompile.
const unsigned int g_uiSamplingFreq = 50000;

// The count of uDMA errors.  This value is incremented by the uDMA error
// handler.  Hopefully this will always remain 0.
volatile unsigned long g_uluDMAErrCount = 0;

// The count of times various uDMA error conditions detected.
volatile unsigned long g_ulBadPeriphIsr1;
volatile unsigned long g_ulBadPeriphIsr2;

//*****************************************************************************
//
// ADC3IntHandler():
//
// EuphonistiHack Notes:
// The interrupt handler for the ADC sequencer used to capture all audio data.
// This handler is called each time the uDMA completes a full ADC->memory copy.
// Yes, that's a bit confusing... the uDMA interrupt is only triggered when the
// uDMA behaves abnormally.  When the uDMA engine completes its transfer, it
// calls the interrupt of whatever module fed it the data, not the uDMA
// interrupt.
//
// Patrick's Notes:
// Took out DMA_METHOD_SLOW so it always transfers with 1024 samples
//
//*****************************************************************************
void
ADC3IntHandler(void)
{
	unsigned long ulStatus;
	static unsigned long uluDMACount = 0;
	static unsigned long ulDataXferd = 0;
	unsigned long ulNextuDMAXferSize = 0;


	// Clear the ADC interrupt
	ADCIntClear(ADC0_BASE, ADC_SEQUENCER);

	// If the channel's not done capturing, we have an error
	if(uDMAChannelIsEnabled(UDMA_CHANNEL_ADC3))
	{
		// Increment error counter
		g_ulBadPeriphIsr2++;

		// Disable the ADC interrupt
		ADCIntDisable(ADC0_BASE, ADC_SEQUENCER);

		// Drop pending interrupts associated with ADC0
		IntPendClear(INT_ADC0SS3);

		// Exit interrupt
		return;
	}// if

	// Verify count remaining is 0.
	// If there are no more items to transfer, returns 0
	// If there are still some items left to transfer, returns positive #
	ulStatus = uDMAChannelSizeGet(UDMA_CHANNEL_ADC3);

	// If non-zero items are left in the transfer buffer
	// Something went wrong
	if(ulStatus)
	{
		// Increment error counter
		g_ulBadPeriphIsr1++;

		// Exit interrupt handler
		return;
	}// if

	// Disable the sampling timer
	TimerDisable(TIMER0_BASE, TIMER_A);

	//
	// If our sample size can be greater than our maximum uDMA transfer
	// size, we might need to set up another uDMA transfer before signaling
	// that we are ready to process the data.
	//

	// how many times the DMA has been full without processing the data
	uluDMACount++;

	// The amount of data transferred increments in sets of 1024
	ulDataXferd += UDMA_XFER_MAX;

	// Not enough samples yet
	// Should run when the first set of samples is finished because 2048 > 1024
	if(NUM_SAMPLES > ulDataXferd)
	{
		//
		// Figure out how many more uDMA transfers are required to completely
		// fill our sample array, which will tell us what size we need our next
		// uDMA transfer to be
		//

		// If the number of samples that are still needed is more than the
		// max transfer size, make the sure to get as many samples as the
		// max transfer size before starting the next transfer
		if((NUM_SAMPLES - ulDataXferd) > UDMA_XFER_MAX)
		{
			ulNextuDMAXferSize = UDMA_XFER_MAX;
		}// if

		// Else the number of samples that are still neede is less than the
		// max transfer size. Only sample up to the amount still needed before
		// transferring
		else
		{
			ulNextuDMAXferSize = NUM_SAMPLES - ulDataXferd;
		}// else

		// Transfer straight to ADCValues?
		//
		//
		uDMAChannelTransferSet(UDMA_CHANNEL_ADC3 | UDMA_PRI_SELECT,
							   UDMA_MODE_BASIC,
							   (void *)(ADC0_BASE + ADC_O_SSFIFO3 + (0x20 * UDMA_ARB_1)),
							   g_ulADCValues + (UDMA_XFER_MAX * uluDMACount),
							   ulNextuDMAXferSize);

		// Enable channel with new settings
		uDMAChannelEnable(UDMA_CHANNEL_ADC3);

		// Reset the timer to maximum
		TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/(g_uiSamplingFreq - 1));

		// Enable the timer with new settings
		TimerEnable(TIMER0_BASE, TIMER_A);
	}// if

	else
	{
		//
		// Since this transfer is now done, disable the interrupt so the
		// handler is not called any more until set up again.  Also need
		// to unpend in case it happened again since we entered this
		// handler
		//

		// Since data will be processed, set counters back to 0
		uluDMACount = 0;
		ulDataXferd = 0;

		// Disable sampling for now while processing
		ADCIntDisable(ADC0_BASE, ADC_SEQUENCER);

		// Remove pending interrupts for the ADC
		IntPendClear(INT_ADC0SS3);

		// Signal that we have new data to be processed
		g_ucDataReady = 1;
	}// else

}// ADC3IntHandler()

//*****************************************************************************
//
// InitADC3Transfer():
//
// EuphonistiHack Notes:
// Initialize the signal capture chain.
// ADC is initialized to capture based on the sampling timer
// uDMA is set up to transfer the samples from the ADC to the global sample
//   array each time a sample is captured by the ADC.
//
// The end result is a very efficient, 90% hardware handled process in which
// the software says "give me a sample" and the hardware interrupts a short
// time later with the data nicely arranged in a convenient location.  I'm not
// gonna lie... this is pretty awesome.
//
// Patrick's Notes:
// So InitSamplingTimer() uses TimerControlTrigger() to make it so that everytime
// Timer0 times out, ADC_TRIGGER_TIMER causes ADC3 to start sampling, calling the
// ADC3IntHandler().
//
// The reason that the touchscreen cannot use TimerControlTrigger() for Timer1
// is beacuse there can only be one TimerControlTrigger() per program. Hence,
// Timer1 is configured with ADCProcessorTrigger()
//
// Todo: Decide if slow method and ast sampling methods are worth it.
// 			Figure out what arbitration size is.
//			Figure out what g_ucDataReady is.
//
//
//*****************************************************************************
void InitADC3Transfer(void)
{
	// Index of g_ulADCValues
    unsigned int uIdx;

    // Set data as not ready to be processed
    g_ucDataReady = 0;

    // Init buffers by setting them all to 0
    // Should go from 0 to 2048
    for(uIdx = 0; uIdx < NUM_SAMPLES; uIdx++)
    {
    	g_ulADCValues[uIdx] = 0;
    }// for

	// Configure and enable the uDMA controller
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UDMA);

	// Enable the uDMA error interrupt
	IntEnable(INT_UDMAERR);

	// Enable uDMA
	uDMAEnable();

	// Sets the base address of the control table
	// The control table is the 1024-byte-aligned base address
	// that was set up with a preprocessor statement earlier
	uDMAControlBaseSet(ucControlTable);

    //
    // Configure the ADC to capture one sample per sampling timer tick
	// which is controled by Timer0
    //

	// Enable and reset the ADC
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    SysCtlPeripheralReset(SYSCTL_PERIPH_ADC0);

    // Set up the ADC so that it will sample when Timer0 times out
    // It is Timer0 which activates the ADC because it was configured
    // with TimerControlTrigger()
    ADCSequenceConfigure(ADC0_BASE, ADC_SEQUENCER, ADC_TRIGGER_TIMER, 0);
    ADCSequenceStepConfigure(ADC0_BASE, ADC_SEQUENCER, 0, ADC_CTL_CH0 |
    							 ADC_CTL_IE | ADC_CTL_END);

    // Enable the sequencer
    // ADC_SEQUENCER should be 3
    ADCSequenceEnable(ADC0_BASE, ADC_SEQUENCER);
    ADCIntEnable(ADC0_BASE, ADC_SEQUENCER);

    //
    // Configure the DMA channel
    //
    uDMAChannelAttributeDisable(UDMA_CHANNEL_ADC3,
								UDMA_ATTR_ALTSELECT | UDMA_ATTR_USEBURST |
								UDMA_ATTR_HIGH_PRIORITY |
								UDMA_ATTR_REQMASK);

    // Use primary data structure for ADC3
    // Uses 16 bit words
    // Do not increment source address
    // Increment destination address by 16 bits
    // What's arbitration size
    uDMAChannelControlSet(UDMA_CHANNEL_ADC3 | UDMA_PRI_SELECT,
						  UDMA_SIZE_16 | UDMA_SRC_INC_NONE |
						  UDMA_DST_INC_16 | UDMA_ARB_1);

	//
    // EuphonistiHack:
	// The uDMA engine has an upper limit of the number of transfers it can
	// complete before it must be configured for a new transfer.  As a result,
	// we need to configure the uDMA engine to transfer as many samples as
	// possible, up to its maximum amount
	//

	// Use primary data structure and use ADC3
	// Use basic transfer
	// Source is something to do with ADC3 address
	// Destination is g_ulADCValues
	// Transfer UDMA_XFER_MAX (1024) samples
	uDMAChannelTransferSet(UDMA_CHANNEL_ADC3 | UDMA_PRI_SELECT,
							   UDMA_MODE_BASIC,
							   (void *)(ADC0_BASE + ADC_O_SSFIFO3 + (0x20 * UDMA_ARB_1)),
							   g_ulADCValues, UDMA_XFER_MAX);

    // Enable the DMA channel
    uDMAChannelEnable(UDMA_CHANNEL_ADC3);
}// InitADC3Transfer()


//*****************************************************************************
//
// Timer0AIntHandler():
//
// EuphonistiHack Notes:
// The interrupt handler for Timer0A.  Originally, this was used to display
// debug information once per second.  Keeping this around for debug, but in
// the final system, this isn't necessary, as ADC capture is triggered at the
// HW level, alleviating the need for a timer interrupt handler.
//
// Patrick's Notes:
// Sampling does not seem to work without this interrupt. I think the above
// comments are wrong. This timer was intialized with TimerControlTrigger,
// meaning that the timer controls the ADC.
//
//
//*****************************************************************************
void
Timer0AIntHandler(void)
{
    // Clear the timer interrupt.
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

}// Timer0AIntHandler

//*****************************************************************************
//
// InitSamplingTimer():
//
// EuphonistiHack Notes:
// Initialize the timer that will trigger the ADC captures
//	Timer0 @ 44.6k kHz (macro'd) sampling frequency
//
// Patrick's Notes:
// The comments made by EuphonistiHack seem incorrect.
// TimerControlTrigger allows this timer to control the ADC.
//
//*****************************************************************************
void
InitSamplingTimer()
{
    //
	// EuphonistiHack:
    // Set up timer0A to be a one shot that interrupts at 44.6kHz
    //
	// Patrick:
	// Wait, but it's not a one-shot, it's periodic. And it's not 44.6kHz,
	// it's macroed to 26 kHz...
	//

	// Enable the timer0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    // Full Width Periodic Timer using Timer0
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

    // Enables ADC trigger output
    TimerControlTrigger(TIMER0_BASE, TIMER_A, true);

    // Set timer by dividing system clock freq by sampling freq
    // to get the # of clock cycles per period
    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/(g_uiSamplingFreq - 1));

    // Enable the sampling interrupt
    IntEnable(INT_TIMER0A);

    // When timer hits zero, call interrupt
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    // Start the sampling timer
	TimerEnable(TIMER0_BASE, TIMER_A);
}// InitSamplingTimer()

//*****************************************************************************
//
// uDMAErrorHandler():
//
// EuphonistiHack Notes:
// The interrupt handler for uDMA errors.  This interrupt will occur if the
// uDMA encounters a bus error while trying to perform a transfer.  Hopefully,
// this code will never be executed.
//
// Patrick's Notes:
// Eh.
//
//*****************************************************************************
void
uDMAErrorHandler(void)
{
    unsigned long ulStatus;

    // Check for uDMA error bit
    ulStatus = uDMAErrorStatusGet();

    // If there is a uDMA error, then clear the error and increment
    // the error counter.
    if(ulStatus)
    {
        uDMAErrorStatusClear();
        g_uluDMAErrCount++;
    }// if
}// uDMAErrorHandler()


