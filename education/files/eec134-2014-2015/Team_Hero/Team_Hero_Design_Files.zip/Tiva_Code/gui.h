/*
 * gui.h
 *
 *  Created on: Apr 18, 2015
 *      Author: pahuynh
 */

#ifndef GUI_H_
#define GUI_H_

// Functions
void InitGui(void);
void updateGui(void);
void Timer3AIntHandler(void);
void InitGuiTimer(void);

#endif /* GUI_H_ */
