/*
 * gui.c
 *
 *  Created on: Apr 18, 2015
 *      Author: pahuynh
 *
 *  Notes for gui.c:
 *  	Defines the canvas for the screens. Also has a timer which periodically
 *  	updates the screen at a frequency of 1 Hz.
 *
 */

// Needed on top of each file
#include <stdint.h>
#include <stdbool.h>

// Other includes, mostly for pins
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

// Includes for the touchscreen to work
#include "grlib/grlib.h"	// Graphic primatives
#include "grlib/widget.h"	// Widget defintions
#include "grlib/canvas.h"	// Canvas definitions ie. CanvasSetText macro
#include "Kentec320x240x16_ssd2119_8bit.h"	//Controls writing and drawing on screen
#include "touch.h"							// Controls touch; currently broken
#include "utils/ustdlib.h"	// Defines usprintf

// For timer and interrupts
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

// Needs speed and reFreq to update the screen
//#include "dsp.h"

#include "gui.h"


//*****************************************************************************
//
// Global Variables:
//
// Todo: Explain this stuff.
//
//*****************************************************************************

// These three string arrays are passed into
// their respective canvases and will display
// the updated values. They cannot be char *
// because the canvas struct only accepts const char *
// To get around this, a CanvasTextSet is used.
char reFreqText[64] = "Received Frequency: ";
char speedText[64] = "Speed: ";
char sampFreqText[64] = "Sampling Frequency: ";

// These hold the updated processed data as well as the
// sampling frequency. If you want to change the sampling
// frequency, change it in dsp.c
// From dsp.c
extern unsigned int reFreq;
extern unsigned int speed;
extern unsigned int g_uiSamplingFreq;



//*****************************************************************************
//
// Canvas Structs:
//
// Todo: Explain how to define these.
//
//*****************************************************************************
Canvas(g_sBackground, 0, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 320, 240,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE),
       ClrMidnightBlue, ClrGray, 0, g_psFontCm20,
       0, 0, 0);

Canvas(g_sTitle, 0, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 320, 20,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT),
       ClrBlue, ClrWhite, ClrWhite, g_psFontCm20,
       "Doppler Mode", 0, 0);

Canvas(g_sSampFreq, 0, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 40, 320, 40,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT),
       ClrBlue, ClrWhite, ClrWhite, g_psFontCm20,
       sampFreqText, 0, 0);

Canvas(g_sReceivedFreq, 0, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 100, 320, 40,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT),
       ClrBlue, ClrWhite, ClrWhite, g_psFontCm20,
       reFreqText, 0, 0);

Canvas(g_sSpeed, 0, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 160, 320, 40,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT),
       ClrBlue, ClrWhite, ClrWhite, g_psFontCm20,
       speedText, 0, 0);


//*****************************************************************************
//
// InitGui():
//
// Initializes touchscreen.
// Adds all the widgets to the screen.
// Root is the parent of the background.
// Background is parent to all the other canvases.
//
//*****************************************************************************

void InitGui(void){

	//
	// Initialize LCD screen
	//
	Kentec320x240x16_SSD2119Init();

    TouchScreenInit();
    TouchScreenCallbackSet(WidgetPointerMessage); // Dunno what it does

    //
    // Add Widgets to screen.
    //
    WidgetAdd(WIDGET_ROOT, (tWidget *)&g_sBackground);
    WidgetAdd((tWidget *)&g_sBackground, (tWidget *)&g_sTitle);
    WidgetAdd((tWidget *)&g_sBackground, (tWidget *)&g_sSampFreq);
    WidgetAdd((tWidget *)&g_sBackground, (tWidget *)&g_sReceivedFreq);
    WidgetAdd((tWidget *)&g_sBackground, (tWidget *)&g_sSpeed);
    WidgetPaint(WIDGET_ROOT);

    //
    // Update Sampling Frequency
    //
    usprintf(sampFreqText,"SampFreq: %d", g_uiSamplingFreq);
    CanvasTextSet(&g_sSampFreq, sampFreqText);
    WidgetPaint((tWidget *)&g_sSampFreq);


}// InitGui

//*****************************************************************************
//
// updateGui():
//
// Takes in the global variables speed and reFreq and updates
// speedText and reFregTest using usprintf and CanvasSetText.
//
// usprintf is a custome version of sprintf that is defined in the
// Tivaware Library source file ustdlib.c; the regular sprintf from
// the standard C library causes problems with the text not updating.
//
// CanvasTextSet is a macro defined in canvas.h that takes in a char *
// and a Canvas Struct *. The macro sets creates a const char * and sets
// it to the passed in text. The macro then has the Canvas Struct * point
// point to the const char *.
//
//*****************************************************************************
void updateGui(void) {

	//
	// Update Received Frequency
	//
    usprintf(reFreqText,"ReFreq: %d", reFreq);
    CanvasTextSet(&g_sReceivedFreq, reFreqText);
    WidgetPaint((tWidget *)&g_sReceivedFreq);

    //
	// Update Received Frequency
    //
    usprintf(speedText,"Speed: %d", speed);
    CanvasTextSet(&g_sSpeed, speedText);
    WidgetPaint((tWidget *)&g_sSpeed);

}// updateGui()


//*****************************************************************************
//
// Timer3AIntHandler():
//
// Just triggers screen update.
// Todo: If not enough sampled data at the beginning, maybe do not update?
//
//
//*****************************************************************************
void
Timer3AIntHandler(void)
{
    // Clear the timer interrupt.
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);

    // Update reFreq and speed
    updateGui();

}// Timer0AIntHandler



//*****************************************************************************
//
// InitGuiTimer():
//
// Initializes Timer3 to run at one Hz.
//
//*****************************************************************************
void
InitGuiTimer()
{
	// Enable the timer0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);

    // Full Width Periodic Timer using Timer0
    TimerConfigure(TIMER3_BASE, TIMER_CFG_PERIODIC);

    // Set timer
    TimerLoadSet(TIMER3_BASE, TIMER_A, SysCtlClockGet()-1);

    // Enable the gui interrupt
    IntEnable(INT_TIMER3A);

    // When timer hits zero, call interrupt
    TimerIntEnable(TIMER3_BASE, TIMER_TIMA_TIMEOUT);

    // Start the gui timer
	TimerEnable(TIMER3_BASE, TIMER_A);
}// InitSamplingTimer()
