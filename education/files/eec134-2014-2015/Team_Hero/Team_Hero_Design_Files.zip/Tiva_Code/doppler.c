/*
 * doppler.c
 *
 *  Created on: Apr 26, 2015
 *      Author: pahuynh
 *
 *  Program Notes:
 *  	This is a fork of program hero2, which is a remake of the EuphonistiHack code.
 *  	Currently the fifth iteration of doppler, which contains only the doppler
 *  	portion of the radar.
 *
 *  	No more DMA_METHOD macros; program is now always set to sample 1024 times before
 *  	triggering a uDMA transfer. Sample input is PE3. FFT runs when there is 2048 samples,
 *  	updating the received frequency and the speed. Screen updates at around one Hz.
 *  	Process data runs in an infinite while loop.
 *
 *  	Certain global variables are shared between gui.c, dsp.c, and sampling.c through
 *  	the use of extern. Make sure to pay attention to where everything is.
 *
 *  	Currently, the sampling frequency needs to be three times the input frequency. Despite
 *  	Nyquist rate being two times the input frequency, extra sampling is needed to account for
 *  	noise.
 *
 *  	Changed priority for touchscreen ADC.
 *
 *  	Todo: Take a lot at Kentec file and compare to old versions.
 *
 *		Todo: Touchscreen currently does not work, due to the software trigger of the ADC.
 *		Only hardware triggers work for ADC at the moment, which is reserved for the sampling.
 *
 *		Todo: Even though SSI should have no overlap with the touchscreen pins,
 *		the screen whites out using certain pins as chip select. Also, when guiInit runs, the DAC
 *		stops working.
 *
 *  Breakdown of overall code organization:
 *  	doppler.c contains main and initialization of floats and system clock. May choose to put
 *  	initialization of SSI here because of the initialization of the infineon chip does not
 *  	fit anywhere else.
 *
 *  	sampling.c contains the control table for uDMA. Defines the sampling frequency, when the
 *  	sampled data is ready, as well as the array to store all the sampled data. Initialization
 *  	adc0ss3 and timer1 are all in sampling.c
 *
 *  	dsp.c defines the recieved frequency and speed. Initializes the fft data structure as well
 *  	as processes the data. Defines number of samples.
 *
 *  	gui.c contains the screen information as well as timer3.
 *
 *		dac.c contains the initliazation of the SSI and timer2.
 *
 *		touch contains timer1 and touchsceen ADC.
 *
 *	Notes for doppler.c:
 *		Todo: May need to rearrange the order of functions called.
 *
 */

// Needed on top of each file
// Defines data types like unint32_t
#include <stdint.h>
#include <stdbool.h>

// Might actually be Model number RB2,
// not defined in Tivaware library.
// So that ROM calls work
// On CCS in debug mode, go to the SYSCTL_DID0 register
// Look at the Major and Minor fields. If both are 0x01,
// then its RB1, revision 6
// If minor is 0x02, then it's revision 7, RB2
#define TARGET_IS_BLIZZARD_RB1
#include "driverlib/rom.h"

// So that WidgetMessageQueueProcess works
#include "grlib/grlib.h"
#include "grlib/widget.h"

// For setting the system clock
#include "driverlib/sysctl.h"

// For timer and interrupts
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"

// Other includes, mostly for pins
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"


// Custom includes
#include "doppler.h"
#include "sampling.h"
#include "gui.h"
#include "dsp.h"
#include "dac.h"

//*****************************************************************************
//
// Global variables
//
//*****************************************************************************

// From sampling.c
// Tell whether or not data is ready to be processed
extern volatile unsigned char g_ucDataReady;


//*****************************************************************************
//
// main():
//
// The actual program
//
//*****************************************************************************
int main(void) {

	// Init system clock and floats
	InitBasics();

	// Init touchscreen, timer1, ADC1SS3, and all the canvases
	InitGui();

	// Init Timer3, updateGui starts running
    InitGuiTimer();

    // Init SSI3
	//InitSSI();

    // Init Timer2
	//InitDACTimer();

	// Init FFT Data Structure
	InitDSP();

	// Init Timer1 at the sampling frequency
	InitSamplingTimer();

	// Init ADC0SS3 and uDMA
	InitADC3Transfer();

	// Start sampling
	IntEnable(INT_ADC0SS3);

	// Not sure if needed
	// Probably needed for software interrupt for touchscreen's ADC
	// Not sure if needed for other interrupts
	IntMasterEnable();

	// Loop
    while(1)
    {
    	// If we have new audio data, handle it
    	if(g_ucDataReady)
    	{
    		ProcessData();
    	}// if

    	// Handle touchscreen
        WidgetMessageQueueProcess();
    }// while

}// main()

//*****************************************************************************
//
// InitBasics():
//
// Initializes the system clock speed, floating point use.
//
//*****************************************************************************
void InitBasics(void) {

	// Enable lazy stacking for interrupt handlers.  This allows floating-point
	// instructions to be used within interrupt handlers, but at the expense of
	// extra stack usage.
	//FPUEnable();
	//FPULazyStackingEnable();
	ROM_FPUEnable();
	ROM_FPULazyStackingEnable();

	// Set clock to 80 MHz
	//ROM_SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |
	//				   SYSCTL_OSC_MAIN);
	SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |
					   SYSCTL_OSC_MAIN);
}// IntiBasics()



