/*
 * dsp.h
 *
 *  Created on: Apr 18, 2015
 *      Author: pahuynh
 */

#ifndef DSP_H_
#define DSP_H_


// Number of samples to capture for each FFT process.  Set to CMSIS max for
// best resolution. Put here because both sampling.c and dsp.c use it.
#define NUM_SAMPLES				2048

// Functions
void InitDSP(void);
void ProcessData(void);


#endif /* DSP_H_ */
