/*
 * dac.h
 *
 *  Created on: May 2, 2015
 *      Author: pahuynh
 */

#ifndef DAC_H_
#define DAC_H_


//
// Preprocessor Macros
// Defines some stuff to make it easier to switch
// between 12 and 16 bit DACs
//

// For toggling between the 12 bit and 16 bit DAC
// DAC_12_BIT_2 is for using two 12 bit DACs
//#define DAC_12_BIT_2    2
//#define DAC_12_BIT		1
//#define DAC_16_BIT		0

// Each DAC has their own peak value
// PEAK_12_BIT should be <= (2^12)-1 = 4095
// PEAK_16_BIT should be <= (2^16)-1 = 65535
#define PEAK_12_BIT		4080
#define PEAK_16_BIT		65000


// Functions
void writeData(uint8_t c);
int highByte(int x);
int lowByte(int x);
void write12bit(void);
//void write12bit2(void);
void write16bit(void);
void InitSSI(void);
void Timer2AIntHandler(void);
void InitDACTimer(void);

#endif /* DAC_H_ */
