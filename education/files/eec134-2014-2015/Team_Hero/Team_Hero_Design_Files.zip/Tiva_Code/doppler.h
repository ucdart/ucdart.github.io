/*
 * doppler.h
 *
 *  Created on: Apr 26, 2015
 *      Author: pahuynh
 */

#ifndef DOPPLER_H_
#define DOPPLER_H_

// Functions
void InitBasics(void);

#endif /* DOPPLER_H_ */
