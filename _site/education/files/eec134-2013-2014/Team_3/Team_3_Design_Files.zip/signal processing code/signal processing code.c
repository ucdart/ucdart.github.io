/* main.c:  test program for 32 bit real FFT and supporting functions for Cortex-M3
--------------------------------------------------------------------------
(c) 2009 Ivan Mellen                                        September 2009
--------------------------------------------------------------------------
imellen(at)embeddedsignals(dot)com
*/

#include "inc/hw_types.h"
#include "inc/hw_ssi.h"
#include "inc/hw_memmap.h"
#include "driverlib/ssi.h" 
#include "driverlib/interrupt.h"
#include "driverlib/debug.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "drivers/rit128x96x4.h"
#include "driverlib/systick.c"
#include "driverlib/systick.h"
#include "drivers/rit128x96x4.h"
#include "driverlib/timer.h"
#include "driverlib/timer.c"
#include "driverlib\adc.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>	// for boolean data type.
//declare functions
#define NN 128
#define sample_freq 4000	// sampling frequency=40000 Hz.
//#define fft_interval 500	// systick disabled
//#define OLED_refresh 500	// systick disabled
#define compare_num 10
#define sample_break 1	// one second between two groups of fft;
#define tolerance 8

void Window16to32b_real(int *x,unsigned short *w,int N);
void FFT128Real_32b(int *y, int *x);
void magnitude32_32bIn(int   *x,int M);


//char outstring[25];
unsigned long ulADC0_Value[2];
int meter1 =0, meter2=0;
bool spectrum = 0;
int flag, first_index=4, i_buffer=0;
int adc0[128], adc1[128], adc0_copy[128], xx_0[50], xx_avg=0;
int max_index[compare_num], y[NN+2], y_buffer[compare_num*2][NN +2], y_subtract[compare_num][NN+2],  y_old[NN+2] , y_avg[NN+2], y_left[NN+2], y_right[NN+2];  // one extra element
unsigned short w[NN/2];
int i = 0, f, systick_done=0, fft_done=0, max_index_count[compare_num], max_index_temp=0, max_index_index=0;
char outstring[25];
unsigned char IntStatus;
int systick_count=0, fft_pass=0;

int MaxElement (int Array[])
{
  int index=1, max=0, n=2;	
	for (n = 2; n <= NN ; n+=2)
   {
      if (Array [n] > max)
			{
				max = Array [n];
				//index = n;
			}
   }
	 return (max);
}

int MinElement_2d (int Array[][NN+2], int k, int start_buffer)
{
  int min=2000, n;	
	for (n = start_buffer; n < compare_num+start_buffer; n++)
   {
      if (Array [n][k] < min)
			{
				min = Array [n][k];
			}
   }
	 return (min);
}

int MaxElement_2d (int Array[][NN+2], int j)
{
  int max=0, k=0;	
	for (k = first_index; k <= NN; k+=2)
   {
      if (Array [j][k] > max)
			{
				max = Array [j][k];
				max_index[j]=k;
			}
   }
	 return(0);
}


int Average_2d (int Array[][NN+2], int k, int start_buffer)
{
	int n, avg=0;	
	for (n = start_buffer; n < compare_num+start_buffer; n++)
   {
      avg = Array [n][k] + avg;
   }
	 return (avg/compare_num);
}



//sysTick interrupt
void SysTick_Handler (void) 
	{	/*
		if(systick_count==OLED_refresh)
		{
			systick_count=0;
			systick_done=1;
		}
		else
		{
			systick_count++;
			if (systick_count==fft_interval) fft_pass=1;
		}*/
	} 

// Select switch is pressed.
void PortF_Handler (void) 
{
	GPIOPinIntClear(GPIO_PORTF_BASE,0x0f);	
	spectrum=!spectrum;
	RIT128x96x4Clear();
}

// Navigation buttons on Stellaris LM3S8962 interrupt
void PortE_Handler (void) 
{
	//unsigned char IntStatus;
	IntStatus = (unsigned char) GPIOPinIntStatus (GPIO_PORTE_BASE, true);
	GPIOPinIntClear(GPIO_PORTE_BASE,0x0f);			// clear all ints from navigation switches				
	//RIT128x96x4StringDraw ("hello", 0, 40, 15);		
	if (((IntStatus & 0x03) == 0x01) && first_index<110) 			// if UP pressed and not DOWN
	{		first_index += 10;	
			sprintf (outstring, "first index = %d   ", first_index);
			RIT128x96x4StringDraw (outstring, 0, 40, 15);
	}

	else if (((IntStatus & 0x03) == 0x02) && first_index>11) 			// if DOWN pressed and not UP
	{		first_index-=10;	 
			sprintf (outstring, "first index = %d   ", first_index);
			RIT128x96x4StringDraw (outstring, 0, 40, 15);
	}
	else	if (((IntStatus & 0x0c) == 0x08) && first_index<124) 			// if RIGHT pressed and not LEFT
	{		first_index+=4;	
			sprintf (outstring, "first index = %d   ", first_index);
			RIT128x96x4StringDraw (outstring, 0, 40, 15);	}	
	
	else if (((IntStatus & 0x0c) == 0x04) && first_index>4) 			// if LEFT pressed and not RIGHT
	{		
			first_index-=4;	
			sprintf (outstring, "first index = %d   ", first_index);
			RIT128x96x4StringDraw (outstring, 0, 40, 15);
	}	
}	
	
	
void ADCTimerHandler(void)
{
	int a=0;
	ADCIntClear(ADC0_BASE, 2);
	
	ADCSequenceDataGet(ADC0_BASE, 2, ulADC0_Value);
	
	//for (a = 0; a<first_index; a++)
	//adc0[a] = 0;
	
	if(i < 128)
	{
		adc0[i] = ulADC0_Value[0];
		adc1[i] = ulADC0_Value[1]>>2;
		i++;
	}
	else if(i > 127)
	{
		flag = 1;
		i = 0;
		//for (a = 0; a<first_index; a++)
		//adc0[a] = 0;
	}

}
/*
void WriteByte (unsigned char Register, unsigned char Data) {

	unsigned long ulAddr;
	unsigned long junk;

	GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_7, 0x00);

	// The address where you want to send the data
	ulAddr = (unsigned long)(Register) ;	

	// Put data into the respective addresses
	SSIDataPut (SSI0_BASE, ulAddr);
	SSIDataPut (SSI0_BASE, (unsigned long) Data);

	while (SSIBusy (SSI0_BASE)) ;

	GPIOPinWrite(GPIO_PORTA_BASE,GPIO_PIN_7, GPIO_PIN_7);

	SSIDataGet (SSI0_BASE, &junk);	// clear values from RX FIFO
	SSIDataGet (SSI0_BASE, &junk);
}
*/
int main(void)
{
	int count = 0, ii, jj;
	int max = 0; 
	int j = 0, k, a, index;
	unsigned long  ulClkFreq, ulTickPeriod;

	
	SysCtlClockSet(SYSCTL_SYSDIV_12 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_8MHZ); 
	RIT128x96x4Init(1000000);	// Initialize the OLED display
	//RIT128x96x4Clear();
	//DAC
	/*
	SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	GPIOPinTypeSSI(GPIO_PORTA_BASE, GPIO_PIN_5 | GPIO_PIN_4 | GPIO_PIN_2);

	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_7);	
	GPIOPadConfigSet(GPIO_PORTA_BASE,GPIO_PIN_7,GPIO_STRENGTH_4MA,GPIO_PIN_TYPE_STD);
	SSIConfigSetExpClk(SSI0_BASE, SysCtlClockGet(), SSI_FRF_MOTO_MODE_0,
                       SSI_MODE_MASTER, 1000000, 8);
	SSIEnable(SSI0_BASE);
	
	//uart
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));
	UARTStdioInit(0);
	*/
	//select
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	GPIOPinTypeGPIOOutput (GPIO_PORTF_BASE, GPIO_PIN_0);
	GPIOPinTypeGPIOInput(GPIO_PORTF_BASE,GPIO_PIN_1);
	GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_0, GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD);
	GPIOPadConfigSet(GPIO_PORTF_BASE,GPIO_PIN_1,GPIO_STRENGTH_4MA,GPIO_PIN_TYPE_STD_WPU);
	
	// The four Navigation buttons on board;
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
  GPIOPinTypeGPIOInput (GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0);
	GPIOPadConfigSet(GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0, GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD_WPU);
  GPIOIntTypeSet (GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0, GPIO_RISING_EDGE);	//GPIOIntTypeSet (GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0, GPIO_LOW_LEVEL);
	GPIOPinIntClear(GPIO_PORTE_BASE,0x0f);			// clear ints from navigation switches
	GPIOPinIntEnable(GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0);  // enable nav sw. interrupts
	IntEnable(INT_GPIOE);
	
	// The Select switch on board;
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
  GPIOPinTypeGPIOInput (GPIO_PORTF_BASE, GPIO_PIN_1);
	GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD_WPU);
  GPIOIntTypeSet (GPIO_PORTF_BASE, GPIO_PIN_1 , GPIO_RISING_EDGE);	//GPIOIntTypeSet (GPIO_PORTE_BASE, GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1 | GPIO_PIN_0, GPIO_LOW_LEVEL);
	GPIOPinIntClear(GPIO_PORTF_BASE,0x0f);			// clear ints from navigation switches
	GPIOPinIntEnable(GPIO_PORTF_BASE,  GPIO_PIN_1 );  // enable nav sw. interrupts
	IntEnable(INT_GPIOF);	
	
	//ADC
	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
		//ADCHardwareOversampleConfigure(ADC0_BASE, 8);//-------------------------------------------------------

	//ADCHardwareOversampleConfigure(ADC0_BASE, 8);
	ADCSequenceConfigure(ADC0_BASE,2, ADC_TRIGGER_TIMER, 0);
	ADCSequenceStepConfigure(ADC0_BASE,2,0,ADC_CTL_CH0);
	ADCSequenceStepConfigure(ADC0_BASE,2,1,ADC_CTL_CH1 | ADC_CTL_IE | ADC_CTL_END);
	ADCSequenceEnable(ADC0_BASE, 2);
	ADCIntEnable(ADC0_BASE, 2);
	ADCIntClear(ADC0_BASE, 2);
	
	//Timer4
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
	TimerControlTrigger(TIMER0_BASE, TIMER_A, true);
	TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet()/sample_freq);
	TimerEnable(TIMER0_BASE, TIMER_A);
	
	IntEnable(INT_ADC0SS2); 
	
	//------------------------------------SysTick set up------------------------------------		
	// clock freq/64 = clocks/interrupt at 64 interrupts/s rate
	ulClkFreq = SysCtlClockGet();
	ulTickPeriod = ulClkFreq/1000 ;	// divided by 2, means 2 Hz.

	// Set SysTick Period (# clocks/interrupt)
	SysTickPeriodSet(ulTickPeriod);
	//SysTickIntEnable();
	//SysTickEnable();
//------------------------------------SysTick set up------------------------------------		


	/*
	y_buffer[1][1]=53;
	y_buffer[2][1]=9;
	y_buffer[3][1]=47;
	y_buffer[4][1]=-67;
	y_buffer[0][1]=109;
	i=MinElement_2d(y_buffer, 1);
	sprintf (outstring, "frequency = %d            ", i);
				RIT128x96x4StringDraw (outstring, 0, 20, 15);
*/
	//for (k=0; k<NN+2; k++)
		//y[k]=0;
	
	while(1)  //infinity loop, multiple benchmarks without restart possible
	{
		/*
		if(count == 0 && !GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_1))//checking select
		{
				ADCIntDisable(ADC0_BASE, 2);
				UARTprintf("1. %d\n", adc0[j++]);
				RIT128x96x4StringDraw("Press Select to Send higher channel's data", 0, 0, 75);
				count = 1;
		}
		else if(count == 1 && !GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_1))
		{
				UARTprintf("2. %d\n", adc1[j++]);
				count = 0;
		}			
		
		//WriteByte(0x09, adc1[j++]);
		if (j > 127)
			j = 0;
		*/
		//if(flag && fft_pass==1)
		if(flag)	
		//if(systick_done==1)
		{
			flag = 0;
			fft_pass=0;
			
			ADCIntDisable(ADC0_BASE, 2);	// pause ADC before fetching circular buffer values;
			for (ii=0;ii<NN;ii++)	// copy all 128 elements from circular buffer_0 to xx_0[];
				{
					adc0_copy[ii]=adc0[ii];	
					//w[ii]=0xffff;
					y[ii]=0;
				} 
				y[128]=0;
				y[129]=0;
			ADCIntEnable(ADC0_BASE, 2);	// resume ADC;
				
			for (k=0;k<NN/2;k++)   w[k]=0xffff;
			//for (k=0;k<NN;k++)   y[k]=0;

		

		
		
			Window16to32b_real(adc0_copy, w, NN);
			FFT128Real_32b(y,adc0_copy);
			magnitude32_32bIn(&y[2],NN/2-1);
			k=1;
		
			//for (k=0;k<=NN;k+=2) y[k+1]=0; //zero imag part of original complex frequency
			for (k=0;k<=NN;k+=2) 
			{
				y[k+1]=0;
				y[k]=((y[k]+16384)>>15); //2Q30 converted to 17Q15 and rounded
				y_buffer[i_buffer][k]=y[k];
			}
			
			if (i_buffer == compare_num)	
			{
				SysCtlDelay(ulClkFreq/3*sample_break);
				i_buffer++;
			}
			else if (i_buffer < compare_num*2-1)	i_buffer++;
			else 
			{

						for (k=0;k<=NN;k+=2)	
						{
							for (j=0;j<compare_num;j++)	
								y_subtract[j][k] = y_buffer[j+compare_num][k] - y_buffer[j][k];	
						}
						
						for (j=0;j<compare_num;j++)
							{
								MaxElement_2d(y_subtract, j);
								max_index_count[j]=0;
							}
						/*
						for (j=0;j<compare_num;j++)
						{
							for (k=j+1;k<compare_num;k++)
								if ((max_index[j]-max_index[k])<=2 || (max_index[j]-max_index[k])>=2)
									max_index_count[j]++;
						}
						*/
						for (j=0;j<compare_num;j++)
						{
							for (k=0;k<compare_num;k++)
								if ((max_index[j]-max_index[k])<=tolerance || (max_index[j]-max_index[k])>=tolerance)
									max_index_count[j]++;
							max_index_count[j]-=1;
						}	
							
						max_index_temp=0;
						for (j=0;j<compare_num;j++)
						{
								if (max_index_count [j] > max_index_temp)
								{
									max_index_temp = max_index_count [j];
									max_index_index = j;
								}
						 }
						
				i_buffer=0;	
				fft_done=1;						
			}
			
			
		}
			//if (i_buffer!=2)	i_buffer++;
			//else i_buffer=0;
			
			//if (systick_done==1  && fft_done==1)
			if (fft_done==1 && spectrum==0)
			{
				//systick_done=0;
				fft_done=0;
				k=1;
				//RIT128x96x4Clear();
				/*
				for(a=first_index; a < NN; a+=2)
				{
					//if((signed)y_subtract[a] > max)
					if(y_subtract[a] > max)	
					{
						//max = (signed)y_subtract[a];
						max = y_subtract[a];
						index = a;
					}
				}
				*/
				f = (((float)max_index[max_index_index] * sample_freq/2) / NN);
				//UARTprintf("frequency : %d\n", f);
				//max = 0;
				//index = 4;
				
				//xx_avg = MaxElement(adc0);
				meter1 = (int)f/200;
				meter2 = (int)(((float)f/200-(int)f/200)*10);
				
				sprintf (outstring, "frequency = %d Hz            ", f);
				RIT128x96x4StringDraw (outstring, 0, 20, 15);
				sprintf (outstring, "distance = %d.%d meters    ",meter1, meter2);
				RIT128x96x4StringDraw (outstring, 0, 40, 15);
				//RIT128x96x4StringDraw ((char)0.2, 0, 40, 15);
				//sprintf (outstring, "max Amp = %d            ", xx_avg);
				//RIT128x96x4StringDraw (outstring, 0, 60, 15);
				
			//RIT128x96x4Clear();
			//for (k=0;k<=NN;k+=2)	
			//{
			//RIT128x96x4StringDraw (".", k, (int)((90-y_subtract[k]/1)), 15);
			//}
					//}
			//}
		}
		
		else if (fft_done==1 && spectrum==1)
		{	
			fft_done=0;
			RIT128x96x4Clear();
			for (k=0;k<=NN;k+=2)	
			{
			RIT128x96x4StringDraw (".", k, (int)((90-y_subtract[compare_num-1][k]/2)), 15);
			}
		}
		
	}
}

